package com.nusa.browser;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.view.MotionEvent;
import android.view.View;

/** Tampilan tangkapan layar; pengguna melingkari bagian yang ingin dicari. */
public class LassoView extends View {

    final Bitmap bmp;
    final Path path = new Path();
    final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
    final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    final Paint pic = new Paint(Paint.FILTER_BITMAP_FLAG);
    float minX, minY, maxX, maxY;
    float scale = 1f, offX, offY;
    boolean has;

    public LassoView(Context c, Bitmap b) {
        super(c);
        bmp = b;
        line.setStyle(Paint.Style.STROKE);
        line.setStrokeWidth(6f);
        line.setColor(0xFFFF5252);
        line.setStrokeJoin(Paint.Join.ROUND);
        line.setStrokeCap(Paint.Cap.ROUND);
        fill.setStyle(Paint.Style.FILL);
        fill.setColor(0x33FF5252);
    }

    void fit() {
        scale = Math.min((float) getWidth() / bmp.getWidth(), (float) getHeight() / bmp.getHeight());
        offX = (getWidth() - bmp.getWidth() * scale) / 2f;
        offY = (getHeight() - bmp.getHeight() * scale) / 2f;
    }

    @Override
    protected void onDraw(Canvas cv) {
        fit();
        cv.save();
        cv.translate(offX, offY);
        cv.scale(scale, scale);
        cv.drawBitmap(bmp, 0, 0, pic);
        cv.restore();
        cv.drawPath(path, fill);
        cv.drawPath(path, line);
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        float x = e.getX(), y = e.getY();
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                path.reset();
                path.moveTo(x, y);
                minX = maxX = x;
                minY = maxY = y;
                has = false;
                break;
            case MotionEvent.ACTION_MOVE:
                path.lineTo(x, y);
                minX = Math.min(minX, x);
                maxX = Math.max(maxX, x);
                minY = Math.min(minY, y);
                maxY = Math.max(maxY, y);
                break;
            case MotionEvent.ACTION_UP:
                path.close();
                has = (maxX - minX) > 40 && (maxY - minY) > 40;
                break;
            default:
                return true;
        }
        invalidate();
        return true;
    }

    void reset() {
        path.reset();
        has = false;
        invalidate();
    }

    /** Potong gambar sesuai kotak lingkaran; null jika belum ada lingkaran. */
    Bitmap crop() {
        if (!has) return null;
        fit();
        int pad = 12;
        int l = Math.max(0, Math.round((minX - offX) / scale) - pad);
        int t = Math.max(0, Math.round((minY - offY) / scale) - pad);
        int r = Math.min(bmp.getWidth(), Math.round((maxX - offX) / scale) + pad);
        int b = Math.min(bmp.getHeight(), Math.round((maxY - offY) / scale) + pad);
        if (r - l < 20 || b - t < 20) return null;
        return Bitmap.createBitmap(bmp, l, t, r - l, b - t);
    }
}
