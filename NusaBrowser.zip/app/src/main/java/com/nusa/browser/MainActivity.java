package com.nusa.browser;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.DownloadManager;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ShortcutInfo;
import android.content.pm.ShortcutManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.drawable.Icon;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.view.Menu;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.webkit.CookieManager;
import android.webkit.URLUtil;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.PopupMenu;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {

    static final String HOME = "file:///android_asset/home.html";
    static final String DESKTOP_UA = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 "
            + "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36";
    static final int REQ_FILE = 1, REQ_STORAGE = 2;

    static final String[][] ENGINES = {
            {"Google", "https://www.google.com/search?q="},
            {"Bing", "https://www.bing.com/search?q="},
            {"DuckDuckGo", "https://duckduckgo.com/?q="},
            {"Brave", "https://search.brave.com/search?q="},
            {"Yahoo", "https://search.yahoo.com/search?p="},
            {"Yandex", "https://yandex.com/search/?text="},
            {"Ecosia", "https://www.ecosia.org/search?q="},
            {"Startpage", "https://www.startpage.com/do/search?q="},
    };

    static class Tab {
        WebView web;
        boolean desktop;
        String title = "";
    }

    final List<Tab> tabs = new ArrayList<>();
    int current = 0, engine = 0;
    SharedPreferences prefs;
    FrameLayout rootLayout, container;
    EditText urlField;
    ProgressBar progress;
    ImageButton backBtn, forwardBtn;
    TextView tabCount;
    View customView;
    WebChromeClient.CustomViewCallback customCb;
    ValueCallback<Uri[]> fileCb;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        prefs = getSharedPreferences("nusa", MODE_PRIVATE);
        engine = Math.min(prefs.getInt("engine", 0), ENGINES.length - 1);

        rootLayout = findViewById(R.id.root);
        container = findViewById(R.id.container);
        urlField = findViewById(R.id.urlField);
        progress = findViewById(R.id.progress);
        backBtn = findViewById(R.id.backBtn);
        forwardBtn = findViewById(R.id.forwardBtn);
        tabCount = findViewById(R.id.tabCount);

        updateHint();
        findViewById(R.id.engineBtn).setOnClickListener(v -> showEngines());
        findViewById(R.id.reloadBtn).setOnClickListener(v -> cur().web.reload());
        backBtn.setOnClickListener(v -> {
            if (cur().web.canGoBack()) cur().web.goBack();
        });
        forwardBtn.setOnClickListener(v -> {
            if (cur().web.canGoForward()) cur().web.goForward();
        });
        findViewById(R.id.tabsBtn).setOnClickListener(v -> showTabs());
        findViewById(R.id.menuBtn).setOnClickListener(this::showMenu);

        urlField.setOnEditorActionListener((v, id, e) -> {
            go(v.getText().toString());
            return true;
        });
        urlField.setOnFocusChangeListener((v, has) -> {
            if (!has) showUrl(cur().web.getUrl());
        });

        Uri d = getIntent().getData();
        newTab(d != null ? d.toString() : HOME);
    }

    @Override
    protected void onNewIntent(Intent i) {
        super.onNewIntent(i);
        setIntent(i);
        Uri d = i.getData();
        if (d != null) newTab(d.toString());
    }

    Tab cur() {
        return tabs.get(current);
    }

    boolean isCur(WebView v) {
        return !tabs.isEmpty() && cur().web == v;
    }

    // ---------- Tab ----------

    void newTab(String url) {
        Tab t = new Tab();
        t.web = new WebView(this);
        setup(t);
        tabs.add(t);
        switchTo(tabs.size() - 1);
        t.web.loadUrl(url);
    }

    void switchTo(int i) {
        current = i;
        container.removeAllViews();
        container.addView(cur().web, new FrameLayout.LayoutParams(-1, -1));
        showUrl(cur().web.getUrl());
        progress.setVisibility(View.INVISIBLE);
        updateUi();
    }

    void closeCurrent() {
        if (tabs.size() == 1) {
            cur().web.loadUrl(HOME);
            return;
        }
        Tab t = tabs.remove(current);
        container.removeAllViews();
        t.web.destroy();
        switchTo(Math.max(0, current - 1));
    }

    void updateUi() {
        tabCount.setText(String.valueOf(tabs.size()));
        backBtn.setAlpha(cur().web.canGoBack() ? 1f : 0.35f);
        forwardBtn.setAlpha(cur().web.canGoForward() ? 1f : 0.35f);
    }

    void showUrl(String u) {
        if (urlField.hasFocus()) return;
        if (u == null || u.startsWith("file:///android_asset")) urlField.setText("");
        else urlField.setText(u.replaceFirst("^https://", ""));
    }

    void focusUrl() {
        urlField.requestFocus();
        InputMethodManager imm = getSystemService(InputMethodManager.class);
        if (imm != null) imm.showSoftInput(urlField, 0);
    }

    // ---------- WebView ----------

    void setup(final Tab t) {
        WebView w = t.web;
        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setSupportZoom(true);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        s.setUseWideViewPort(true);
        s.setLoadWithOverviewMode(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        CookieManager.getInstance().setAcceptThirdPartyCookies(w, true);

        w.setDownloadListener((url, ua, cd, mime, len) -> download(url, ua, cd, mime));

        w.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                String u = r.getUrl().toString();
                if (u.startsWith("http") || u.startsWith("file:") || u.startsWith("about:")
                        || u.startsWith("data:") || u.startsWith("javascript:")) return false;
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, r.getUrl()));
                } catch (Exception e) {
                    toast("Tidak ada aplikasi untuk membuka tautan ini");
                }
                return true;
            }

            @Override
            public void onPageStarted(WebView v, String u, Bitmap icon) {
                if (isCur(v)) {
                    showUrl(u);
                    updateUi();
                }
            }

            @Override
            public void onPageFinished(WebView v, String u) {
                t.title = v.getTitle();
                if (isCur(v)) {
                    showUrl(u);
                    updateUi();
                }
            }
        });

        w.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView v, int p) {
                if (isCur(v)) {
                    progress.setProgress(p);
                    progress.setVisibility(p < 100 ? View.VISIBLE : View.INVISIBLE);
                }
            }

            @Override
            public void onReceivedTitle(WebView v, String title) {
                t.title = title;
            }

            @Override
            public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (fileCb != null) fileCb.onReceiveValue(null);
                fileCb = cb;
                try {
                    startActivityForResult(p.createIntent(), REQ_FILE);
                } catch (Exception e) {
                    fileCb = null;
                    return false;
                }
                return true;
            }

            @Override
            public void onShowCustomView(View view, CustomViewCallback cb) {
                if (customView != null) {
                    cb.onCustomViewHidden();
                    return;
                }
                customView = view;
                customCb = cb;
                rootLayout.addView(view, new FrameLayout.LayoutParams(-1, -1));
                getWindow().getDecorView().setSystemUiVisibility(
                        View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
            }

            @Override
            public void onHideCustomView() {
                hideCustom();
            }
        });
    }

    void hideCustom() {
        if (customView == null) return;
        rootLayout.removeView(customView);
        customView = null;
        if (customCb != null) customCb.onCustomViewHidden();
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
    }

    @Override
    protected void onActivityResult(int rq, int rs, Intent d) {
        super.onActivityResult(rq, rs, d);
        if (rq == REQ_FILE && fileCb != null) {
            fileCb.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(rs, d));
            fileCb = null;
        }
    }

    @Override
    public void onBackPressed() {
        if (customView != null) {
            hideCustom();
        } else if (cur().web.canGoBack()) {
            cur().web.goBack();
        } else if (tabs.size() > 1) {
            closeCurrent();
        } else {
            super.onBackPressed();
        }
    }

    // ---------- Navigasi & pencarian ----------

    void go(String in) {
        String q = in.trim();
        if (q.isEmpty()) return;
        String url;
        if (q.matches("^[a-zA-Z][a-zA-Z0-9+.-]*://.*")) url = q;
        else if (!q.contains(" ") && q.contains(".")) url = "https://" + q;
        else url = ENGINES[engine][1] + Uri.encode(q);
        cur().web.loadUrl(url);
        InputMethodManager imm = getSystemService(InputMethodManager.class);
        if (imm != null) imm.hideSoftInputFromWindow(urlField.getWindowToken(), 0);
        urlField.clearFocus();
    }

    void updateHint() {
        urlField.setHint("Cari di " + ENGINES[engine][0] + " atau ketik alamat");
    }

    void showEngines() {
        String[] n = new String[ENGINES.length];
        for (int i = 0; i < n.length; i++) n[i] = ENGINES[i][0];
        new AlertDialog.Builder(this)
                .setTitle("Mesin pencari")
                .setSingleChoiceItems(n, engine, (d, i) -> {
                    engine = i;
                    prefs.edit().putInt("engine", i).apply();
                    updateHint();
                    d.dismiss();
                })
                .show();
    }

    // ---------- Menu ----------

    void showMenu(View anchor) {
        PopupMenu m = new PopupMenu(this, anchor);
        Menu mm = m.getMenu();
        mm.add(0, 1, 0, "Tab baru");
        mm.add(0, 2, 1, "Tutup tab ini");
        mm.add(0, 3, 2, "Pintasan ke layar utama");
        mm.add(0, 4, 3, "Mode baca");
        mm.add(0, 5, 4, "DevTools");
        mm.add(0, 6, 5, "Mode desktop").setCheckable(true).setChecked(cur().desktop);
        mm.add(0, 7, 6, "Unduhan");
        mm.add(0, 8, 7, "Mesin pencari");
        m.setOnMenuItemClickListener(i -> {
            switch (i.getItemId()) {
                case 1:
                    newTab(HOME);
                    focusUrl();
                    break;
                case 2:
                    closeCurrent();
                    break;
                case 3:
                    addShortcut();
                    break;
                case 4:
                    cur().web.evaluateJavascript(asset("reader.js"), null);
                    break;
                case 5:
                    cur().web.evaluateJavascript(
                            "(function(){if(window.eruda){eruda.show();return;}"
                                    + "var s=document.createElement('script');"
                                    + "s.src='https://cdn.jsdelivr.net/npm/eruda@3.0.1';"
                                    + "s.onload=function(){eruda.init();eruda.show();};"
                                    + "document.body.appendChild(s);})();", null);
                    break;
                case 6:
                    toggleDesktop();
                    break;
                case 7:
                    showDownloads();
                    break;
                case 8:
                    showEngines();
                    break;
            }
            return true;
        });
        m.show();
    }

    void showTabs() {
        String[] n = new String[tabs.size()];
        for (int i = 0; i < n.length; i++) {
            String s = tabs.get(i).title;
            if (s == null || s.isEmpty()) s = "Tab baru";
            n[i] = (i == current ? "● " : "○ ") + s;
        }
        new AlertDialog.Builder(this)
                .setTitle("Tab (" + n.length + ")")
                .setItems(n, (d, i) -> switchTo(i))
                .setPositiveButton("Tab baru", (d, w) -> {
                    newTab(HOME);
                    focusUrl();
                })
                .setNeutralButton("Tutup tab ini", (d, w) -> closeCurrent())
                .setNegativeButton("Batal", null)
                .show();
    }

    void toggleDesktop() {
        Tab t = cur();
        t.desktop = !t.desktop;
        t.web.getSettings().setUserAgentString(t.desktop ? DESKTOP_UA : null);
        t.web.reload();
        toast(t.desktop ? "Mode desktop aktif" : "Mode desktop mati");
    }

    void addShortcut() {
        String url = cur().web.getUrl();
        if (url == null || url.startsWith("file:")) {
            toast("Buka sebuah situs dulu");
            return;
        }
        ShortcutManager sm = getSystemService(ShortcutManager.class);
        if (sm == null || !sm.isRequestPinShortcutSupported()) {
            toast("Launcher tidak mendukung pintasan");
            return;
        }
        String label = cur().web.getTitle();
        if (label == null || label.trim().isEmpty()) label = url;
        if (label.length() > 24) label = label.substring(0, 24);
        Intent i = new Intent(this, MainActivity.class)
                .setAction(Intent.ACTION_VIEW)
                .setData(Uri.parse(url));
        ShortcutInfo info = new ShortcutInfo.Builder(this, "u" + url.hashCode())
                .setShortLabel(label)
                .setIcon(Icon.createWithResource(this, R.mipmap.ic_launcher))
                .setIntent(i)
                .build();
        sm.requestPinShortcut(info, null);
    }

    // ---------- Unduhan ----------

    void download(String url, String ua, String cd, String mime) {
        if (Build.VERSION.SDK_INT <= 28
                && checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQ_STORAGE);
            toast("Izinkan penyimpanan, lalu unduh lagi");
            return;
        }
        try {
            String name = URLUtil.guessFileName(url, cd, mime);
            DownloadManager.Request r = new DownloadManager.Request(Uri.parse(url));
            r.setMimeType(mime);
            r.addRequestHeader("User-Agent", ua);
            String ck = CookieManager.getInstance().getCookie(url);
            if (ck != null) r.addRequestHeader("Cookie", ck);
            r.setTitle(name);
            r.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            r.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name);
            ((DownloadManager) getSystemService(DOWNLOAD_SERVICE)).enqueue(r);
            toast("Mengunduh: " + name);
        } catch (Exception e) {
            toast("Gagal mengunduh file ini");
        }
    }

    void showDownloads() {
        DownloadManager dm = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
        final List<String> names = new ArrayList<>();
        final List<Long> ids = new ArrayList<>();
        Cursor c = dm.query(new DownloadManager.Query());
        if (c != null) {
            try {
                while (c.moveToNext() && names.size() < 50) {
                    long id = c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_ID));
                    String title = c.getString(c.getColumnIndexOrThrow(DownloadManager.COLUMN_TITLE));
                    int st = c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS));
                    String mark = st == DownloadManager.STATUS_SUCCESSFUL ? "✓ "
                            : st == DownloadManager.STATUS_FAILED ? "✗ " : "… ";
                    names.add(mark + (title == null ? "file" : title));
                    ids.add(id);
                }
            } finally {
                c.close();
            }
        }
        AlertDialog.Builder b = new AlertDialog.Builder(this).setTitle("Unduhan");
        if (names.isEmpty()) b.setMessage("Belum ada unduhan.");
        else b.setItems(names.toArray(new String[0]), (d, i) -> openDownload(ids.get(i)));
        b.setNeutralButton("Buka folder", (d, w) -> {
            try {
                startActivity(new Intent(DownloadManager.ACTION_VIEW_DOWNLOADS));
            } catch (Exception e) {
                toast("Tidak bisa membuka folder");
            }
        });
        b.setPositiveButton("Tutup", null);
        b.show();
    }

    void openDownload(long id) {
        DownloadManager dm = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
        Uri u = dm.getUriForDownloadedFile(id);
        if (u == null) {
            toast("Unduhan belum selesai atau gagal");
            return;
        }
        try {
            startActivity(new Intent(Intent.ACTION_VIEW)
                    .setDataAndType(u, dm.getMimeTypeForDownloadedFile(id))
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION));
        } catch (Exception e) {
            toast("Tidak ada aplikasi untuk membuka file ini");
        }
    }

    // ---------- Util ----------

    String asset(String name) {
        try (InputStream in = getAssets().open(name);
             ByteArrayOutputStream o = new ByteArrayOutputStream()) {
            byte[] buf = new byte[4096];
            int r;
            while ((r = in.read(buf)) > 0) o.write(buf, 0, r);
            return new String(o.toByteArray(), StandardCharsets.UTF_8);
        } catch (IOException e) {
            return "";
        }
    }

    void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }
}
