package com.nusa.browser;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.DownloadManager;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ShortcutInfo;
import android.content.pm.ShortcutManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.Rect;
import android.graphics.drawable.Icon;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.util.Base64;
import android.view.Gravity;
import android.view.Menu;
import android.view.PixelCopy;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.webkit.CookieManager;
import android.webkit.SafeBrowsingResponse;
import android.webkit.URLUtil;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class MainActivity extends Activity {

    static final String HOME = "file:///android_asset/home.html";
    static final String DESKTOP_UA = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 "
            + "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36";
    static final int REQ_FILE = 1, REQ_STORAGE = 2;

    static final String[][] ENGINES = {
            {"Google", "https://www.google.com/search?q="},
            {"Bing", "https://www.bing.com/search?q="},
            {"DuckDuckGo", "https://duckduckgo.com/?q="},
            {"Brave", "https://search.brave.com/search?q="},
            {"Yahoo", "https://search.yahoo.com/search?p="},
            {"Yandex", "https://yandex.com/search/?text="},
            {"Ecosia", "https://www.ecosia.org/search?q="},
            {"Startpage", "https://www.startpage.com/do/search?q="},
    };

    // {nama, alamat unggah, nama field, mode}; mode "file" = kirim sebagai file, "text" = kirim base64
    static final String[][] IMG = {
            {"Google Lens", "https://lens.google.com/v3/upload", "encoded_image", "file"},
            {"Yandex", "https://yandex.com/images/search?rpt=imageview", "upfile", "file"},
            {"Bing", "https://www.bing.com/images/search?view=detailv2&iss=sbiupload&FORM=SBIHMP", "imageBin", "text"},
            {"TinEye", "https://tineye.com/search", "image", "file"},
    };

    static final String[][] LANGS = {
            {"Indonesia", "id"}, {"Inggris", "en"}, {"Jepang", "ja"}, {"Korea", "ko"},
            {"Mandarin", "zh-CN"}, {"Arab", "ar"}, {"Spanyol", "es"}, {"Prancis", "fr"},
            {"Jerman", "de"}, {"Rusia", "ru"},
    };

    static final String[] AD_HOSTS = {
            "doubleclick.net", "googlesyndication.com", "googleadservices.com", "adservice.google.com",
            "googletagservices.com", "adnxs.com", "adsrvr.org", "advertising.com", "adform.net",
            "criteo.com", "criteo.net", "taboola.com", "outbrain.com", "revcontent.com", "mgid.com",
            "pubmatic.com", "rubiconproject.com", "openx.net", "casalemedia.com", "indexww.com",
            "contextweb.com", "sovrn.com", "lijit.com", "smartadserver.com", "amazon-adsystem.com",
            "media.net", "moatads.com", "scorecardresearch.com", "quantserve.com", "adsafeprotected.com",
            "doubleverify.com", "serving-sys.com", "bidswitch.net", "3lift.com", "sharethrough.com",
            "teads.tv", "tapad.com", "bluekai.com", "krxd.net", "exelator.com", "rlcdn.com",
            "demdex.net", "everesttech.net", "adcolony.com", "applovin.com", "unityads.unity3d.com",
            "mopub.com", "inmobi.com", "vungle.com", "chartboost.com", "ironsrc.com",
            "supersonicads.com", "startapp.com", "popads.net", "popcash.net", "propellerads.com",
            "propellerclick.com", "exoclick.com", "exosrv.com", "juicyads.com", "trafficjunky.net",
            "trafficfactory.biz", "clickadu.com", "hilltopads.net", "adsterra.com", "a-ads.com",
            "onclickads.net", "adskeeper.com", "yllix.com", "zedo.com", "yieldmo.com", "undertone.com",
            "adblade.com", "bidvertiser.com", "infolinks.com", "adroll.com", "adcash.com",
            "ads.yahoo.com", "analytics.yahoo.com", "adsco.re", "richpush.co",
    };
    static final Set<String> AD_SET = new HashSet<>(Arrays.asList(AD_HOSTS));

    static class Tab {
        WebView web;
        boolean desktop;
        String title = "";
    }

    final List<Tab> tabs = new ArrayList<>();
    Tab splitTab;
    int current = 0, engine = 0;
    volatile boolean adBlock = true;
    SharedPreferences prefs;
    FrameLayout rootLayout, container, splitContainer;
    LinearLayout splitPanel;
    EditText urlField;
    ProgressBar progress;
    ImageButton backBtn, forwardBtn;
    TextView tabCount, splitTitle;
    View customView, lassoBox;
    WebChromeClient.CustomViewCallback customCb;
    ValueCallback<Uri[]> fileCb;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        prefs = getSharedPreferences("nusa", MODE_PRIVATE);
        engine = Math.min(prefs.getInt("engine", 0), ENGINES.length - 1);
        adBlock = prefs.getBoolean("adblock", true);

        rootLayout = findViewById(R.id.root);
        container = findViewById(R.id.container);
        splitPanel = findViewById(R.id.splitPanel);
        splitContainer = findViewById(R.id.splitContainer);
        splitTitle = findViewById(R.id.splitTitle);
        urlField = findViewById(R.id.urlField);
        progress = findViewById(R.id.progress);
        backBtn = findViewById(R.id.backBtn);
        forwardBtn = findViewById(R.id.forwardBtn);
        tabCount = findViewById(R.id.tabCount);

        updateHint();
        findViewById(R.id.engineBtn).setOnClickListener(v -> showEngines());
        findViewById(R.id.reloadBtn).setOnClickListener(v -> cur().web.reload());
        backBtn.setOnClickListener(v -> {
            if (cur().web.canGoBack()) cur().web.goBack();
        });
        forwardBtn.setOnClickListener(v -> {
            if (cur().web.canGoForward()) cur().web.goForward();
        });
        findViewById(R.id.tabsBtn).setOnClickListener(v -> showTabs());
        findViewById(R.id.menuBtn).setOnClickListener(this::showMenu);
        findViewById(R.id.splitClose).setOnClickListener(v -> closeSplit());
        findViewById(R.id.splitOpen).setOnClickListener(v -> {
            if (splitTab == null) return;
            String su = splitTab.web.getUrl();
            closeSplit();
            if (su != null) newTab(su);
        });

        urlField.setOnEditorActionListener((v, id, e) -> {
            go(v.getText().toString());
            return true;
        });
        urlField.setOnFocusChangeListener((v, has) -> {
            if (!has) showUrl(cur().web.getUrl());
        });

        Uri d = getIntent().getData();
        newTab(d != null ? d.toString() : null);
    }

    @Override
    protected void onNewIntent(Intent i) {
        super.onNewIntent(i);
        setIntent(i);
        Uri d = i.getData();
        if (d != null) newTab(d.toString());
    }

    Tab cur() {
        return tabs.get(current);
    }

    boolean isCur(WebView v) {
        return !tabs.isEmpty() && cur().web == v;
    }

    static boolean isHome(String u) {
        return u != null && u.startsWith("file:///android_asset");
    }

    int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    // ---------- Tab ----------

    Tab createTab() {
        Tab t = new Tab();
        t.web = new WebView(this);
        setup(t);
        tabs.add(t);
        switchTo(tabs.size() - 1);
        return t;
    }

    void newTab(String url) {
        Tab t = createTab();
        if (url == null) loadHome(t.web);
        else t.web.loadUrl(url);
    }

    void switchTo(int i) {
        current = i;
        container.removeAllViews();
        container.addView(cur().web, new FrameLayout.LayoutParams(-1, -1));
        showUrl(cur().web.getUrl());
        progress.setVisibility(View.INVISIBLE);
        updateUi();
    }

    void closeCurrent() {
        if (tabs.size() == 1) {
            loadHome(cur().web);
            return;
        }
        Tab t = tabs.remove(current);
        container.removeAllViews();
        t.web.destroy();
        switchTo(Math.max(0, current - 1));
    }

    void updateUi() {
        tabCount.setText(String.valueOf(tabs.size()));
        backBtn.setAlpha(cur().web.canGoBack() ? 1f : 0.35f);
        forwardBtn.setAlpha(cur().web.canGoForward() ? 1f : 0.35f);
    }

    void showUrl(String u) {
        if (urlField.hasFocus()) return;
        if (u == null || isHome(u)) urlField.setText("");
        else urlField.setText(u.replaceFirst("^https://", ""));
    }

    void focusUrl() {
        urlField.requestFocus();
        InputMethodManager imm = getSystemService(InputMethodManager.class);
        if (imm != null) imm.showSoftInput(urlField, 0);
    }

    // ---------- Halaman Home (logo + pintasan tersimpan) ----------

    static String esc(String s) {
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
                .replace("\"", "&quot;").replace("'", "&#39;");
    }

    void loadHome(WebView w) {
        StringBuilder sb = new StringBuilder();
        sb.append("<!doctype html><html><head><meta charset=utf-8>")
                .append("<meta name=viewport content='width=device-width,initial-scale=1'>")
                .append("<title>Nusa Browser</title><style>")
                .append("body{margin:0;padding:48px 16px 24px;background:#fff;font-family:sans-serif;color:#222;text-align:center}")
                .append("img.l{width:84px;height:84px;border-radius:20px}")
                .append("h1{font-weight:500;font-size:20px;margin:12px 0 2px;letter-spacing:1px}")
                .append("p{color:#888;font-size:13px;margin:0 0 28px}")
                .append(".g{display:flex;flex-wrap:wrap;justify-content:center;gap:14px 6px}")
                .append("a.t{width:76px;text-decoration:none;color:#444}")
                .append(".i{display:block;width:52px;height:52px;line-height:52px;margin:0 auto 6px;")
                .append("border-radius:50%;background:#F1F3F4;font-size:22px;color:#C62828;font-weight:600}")
                .append(".n{display:block;font-size:12px;overflow:hidden;white-space:nowrap;text-overflow:ellipsis}")
                .append("</style></head><body><img class=l src='logo.png'><h1>Nusa Browser</h1>")
                .append("<p>Ketik alamat atau kata kunci di atas</p><div class=g>");
        for (String[] bm : readList("bm")) {
            String t = bm[0].isEmpty() ? bm[1] : bm[0];
            sb.append("<a class=t href=\"").append(esc(bm[1])).append("\"><span class=i>")
                    .append(esc(t.substring(0, 1).toUpperCase())).append("</span><span class=n>")
                    .append(esc(t)).append("</span></a>");
        }
        sb.append("</div></body></html>");
        w.loadDataWithBaseURL("file:///android_asset/", sb.toString(), "text/html", "UTF-8", HOME);
    }

    // ---------- Penyimpanan daftar (pintasan Home & riwayat) ----------

    List<String[]> readList(String key) {
        List<String[]> r = new ArrayList<>();
        try {
            JSONArray a = new JSONArray(prefs.getString(key, "[]"));
            for (int i = 0; i < a.length(); i++) {
                JSONArray p = a.getJSONArray(i);
                r.add(new String[]{p.getString(0), p.getString(1)});
            }
        } catch (Exception e) {
            // data rusak: anggap kosong
        }
        return r;
    }

    void writeList(String key, List<String[]> l) {
        JSONArray a = new JSONArray();
        for (String[] p : l) {
            JSONArray q = new JSONArray();
            q.put(p[0]);
            q.put(p[1]);
            a.put(q);
        }
        prefs.edit().putString(key, a.toString()).apply();
    }

    static boolean sameUrl(String a, String b) {
        return a.replaceAll("/+$", "").equals(b.replaceAll("/+$", ""));
    }

    static boolean isWebUrl(String u) {
        return u != null && u.startsWith("http") && !u.contains("nusa.invalid");
    }

    void addBookmark() {
        String u = cur().web.getUrl();
        if (!isWebUrl(u)) {
            toast("Buka sebuah situs dulu");
            return;
        }
        List<String[]> l = readList("bm");
        for (String[] bm : l) {
            if (sameUrl(bm[1], u)) {
                toast("Sudah ada di Home");
                return;
            }
        }
        String t = cur().web.getTitle();
        if (t == null || t.trim().isEmpty()) t = Uri.parse(u).getHost();
        if (t == null) t = u;
        l.add(new String[]{t.trim(), u});
        writeList("bm", l);
        toast("Disimpan ke Home");
    }

    void removeBookmark(String url) {
        List<String[]> l = readList("bm");
        l.removeIf(bm -> sameUrl(bm[1], url));
        writeList("bm", l);
        toast("Dihapus dari Home");
        if (isHome(cur().web.getUrl())) loadHome(cur().web);
    }

    void addHistory(String title, String url) {
        if (!isWebUrl(url)) return;
        String t = title == null ? "" : title;
        List<String[]> l = readList("hist");
        if (!l.isEmpty() && l.get(0)[1].equals(url)) l.get(0)[0] = t;
        else l.add(0, new String[]{t, url});
        while (l.size() > 300) l.remove(l.size() - 1);
        writeList("hist", l);
    }

    void showHistory() {
        List<String[]> l = readList("hist");
        if (l.isEmpty()) {
            toast("Riwayat kosong");
            return;
        }
        int n = Math.min(l.size(), 100);
        String[] items = new String[n];
        for (int k = 0; k < n; k++) {
            String t = l.get(k)[0].isEmpty() ? l.get(k)[1] : l.get(k)[0];
            items[k] = t + "\n" + l.get(k)[1].replaceFirst("^https?://", "");
        }
        new AlertDialog.Builder(this)
                .setTitle("Riwayat")
                .setItems(items, (d, i) -> cur().web.loadUrl(l.get(i)[1]))
                .setNegativeButton("Tutup", null)
                .show();
    }

    void showSettings() {
        String[] items = {
                "Pemblokir iklan: " + (adBlock ? "AKTIF" : "MATI"),
                "Hapus riwayat",
        };
        new AlertDialog.Builder(this)
                .setTitle("Pengaturan")
                .setItems(items, (d, i) -> {
                    if (i == 0) {
                        adBlock = !adBlock;
                        prefs.edit().putBoolean("adblock", adBlock).apply();
                        toast("Pemblokir iklan " + (adBlock ? "aktif" : "mati"));
                    } else {
                        prefs.edit().remove("hist").apply();
                        toast("Riwayat dihapus");
                    }
                })
                .setNegativeButton("Tutup", null)
                .show();
    }

    // ---------- WebView ----------

    static boolean isAd(String host) {
        if (host == null) return false;
        while (true) {
            if (AD_SET.contains(host)) return true;
            int i = host.indexOf('.');
            if (i < 0) return false;
            host = host.substring(i + 1);
        }
    }

    boolean isOfflineUrl(String u) {
        return u.startsWith(Uri.fromFile(offlineDir()).toString());
    }

    void setup(final Tab t) {
        WebView w = t.web;
        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setSupportZoom(true);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        s.setUseWideViewPort(true);
        s.setLoadWithOverviewMode(true);
        s.setAllowFileAccess(true);
        s.setSafeBrowsingEnabled(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        CookieManager.getInstance().setAcceptThirdPartyCookies(w, true);

        w.setDownloadListener((url, ua, cd, mime, len) -> download(url, ua, cd, mime));

        w.setOnLongClickListener(v -> {
            WebView.HitTestResult r = ((WebView) v).getHitTestResult();
            int ty = r.getType();
            String ex = r.getExtra();
            if (ex != null && ex.startsWith("http")
                    && (ty == WebView.HitTestResult.SRC_ANCHOR_TYPE
                    || ty == WebView.HitTestResult.SRC_IMAGE_ANCHOR_TYPE)) {
                linkHold((WebView) v, ex);
                return true;
            }
            return false;
        });

        w.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                String u = r.getUrl().toString();
                if (u.startsWith("http") || u.startsWith("about:") || u.startsWith("data:")
                        || u.startsWith("javascript:")) return false;
                if (u.startsWith("file:")) return !(isHome(u) || isOfflineUrl(u));
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, r.getUrl()));
                } catch (Exception e) {
                    toast("Tidak ada aplikasi untuk membuka tautan ini");
                }
                return true;
            }

            @Override
            public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                if (adBlock && !r.isForMainFrame() && isAd(r.getUrl().getHost())) {
                    return new WebResourceResponse("text/plain", "UTF-8",
                            new ByteArrayInputStream(new byte[0]));
                }
                return null;
            }

            @Override
            public void onSafeBrowsingHit(WebView v, WebResourceRequest r, int type,
                                          SafeBrowsingResponse cb) {
                cb.backToSafety(true);
                String s = type == SAFE_BROWSING_THREAT_PHISHING ? "penipuan (phishing)"
                        : type == SAFE_BROWSING_THREAT_MALWARE ? "malware"
                        : type == SAFE_BROWSING_THREAT_UNWANTED_SOFTWARE ? "software tidak diinginkan"
                        : "berbahaya";
                toast("Situs diblokir: " + s);
            }

            @Override
            public void onPageStarted(WebView v, String u, Bitmap icon) {
                if (isCur(v)) {
                    showUrl(u);
                    updateUi();
                }
            }

            @Override
            public void onPageFinished(WebView v, String u) {
                t.title = v.getTitle();
                if (isCur(v)) {
                    showUrl(u);
                    updateUi();
                    addHistory(v.getTitle(), u);
                }
            }
        });

        w.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView v, int p) {
                if (isCur(v)) {
                    progress.setProgress(p);
                    progress.setVisibility(p < 100 ? View.VISIBLE : View.INVISIBLE);
                }
            }

            @Override
            public void onReceivedTitle(WebView v, String title) {
                t.title = title;
                if (t == splitTab) splitTitle.setText(title);
            }

            @Override
            public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (fileCb != null) fileCb.onReceiveValue(null);
                fileCb = cb;
                try {
                    startActivityForResult(p.createIntent(), REQ_FILE);
                } catch (Exception e) {
                    fileCb = null;
                    return false;
                }
                return true;
            }

            @Override
            public void onShowCustomView(View view, CustomViewCallback cb) {
                if (customView != null) {
                    cb.onCustomViewHidden();
                    return;
                }
                customView = view;
                customCb = cb;
                rootLayout.addView(view, new FrameLayout.LayoutParams(-1, -1));
                getWindow().getDecorView().setSystemUiVisibility(
                        View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
            }

            @Override
            public void onHideCustomView() {
                hideCustom();
            }
        });
    }

    void hideCustom() {
        if (customView == null) return;
        rootLayout.removeView(customView);
        customView = null;
        if (customCb != null) customCb.onCustomViewHidden();
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
    }

    @Override
    protected void onActivityResult(int rq, int rs, Intent d) {
        super.onActivityResult(rq, rs, d);
        if (rq == REQ_FILE && fileCb != null) {
            fileCb.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(rs, d));
            fileCb = null;
        }
    }

    @Override
    public void onBackPressed() {
        if (customView != null) {
            hideCustom();
        } else if (lassoBox != null) {
            closeLasso();
        } else if (splitTab != null) {
            if (splitTab.web.canGoBack()) splitTab.web.goBack();
            else closeSplit();
        } else if (cur().web.canGoBack()) {
            cur().web.goBack();
        } else if (tabs.size() > 1) {
            closeCurrent();
        } else {
            super.onBackPressed();
        }
    }

    // ---------- Split screen (tahan tautan) ----------

    void linkHold(WebView src, String url) {
        if (src == cur().web && isHome(src.getUrl())) {
            new AlertDialog.Builder(this)
                    .setTitle(url.replaceFirst("^https?://", ""))
                    .setItems(new String[]{"Pratinjau", "Buka di tab baru", "Hapus dari Home"}, (d, i) -> {
                        if (i == 0) showSplit(url);
                        else if (i == 1) newTab(url);
                        else removeBookmark(url);
                    })
                    .show();
        } else {
            showSplit(url);
        }
    }

    void showSplit(String url) {
        if (splitTab == null) {
            splitTab = new Tab();
            splitTab.web = new WebView(this);
            setup(splitTab);
            splitContainer.addView(splitTab.web, new FrameLayout.LayoutParams(-1, -1));
        }
        splitPanel.setVisibility(View.VISIBLE);
        splitTitle.setText(url);
        splitTab.web.loadUrl(url);
    }

    void closeSplit() {
        if (splitTab == null) return;
        splitContainer.removeAllViews();
        splitTab.web.destroy();
        splitTab = null;
        splitPanel.setVisibility(View.GONE);
    }

    // ---------- Navigasi & pencarian ----------

    void go(String in) {
        String q = in.trim();
        if (q.isEmpty()) return;
        String url;
        if (q.matches("^[a-zA-Z][a-zA-Z0-9+.-]*://.*")) url = q;
        else if (!q.contains(" ") && q.contains(".")) url = "https://" + q;
        else url = ENGINES[engine][1] + Uri.encode(q);
        cur().web.loadUrl(url);
        InputMethodManager imm = getSystemService(InputMethodManager.class);
        if (imm != null) imm.hideSoftInputFromWindow(urlField.getWindowToken(), 0);
        urlField.clearFocus();
    }

    void updateHint() {
        urlField.setHint("Cari di " + ENGINES[engine][0] + " atau ketik alamat");
    }

    void showEngines() {
        String[] n = new String[ENGINES.length];
        for (int i = 0; i < n.length; i++) n[i] = ENGINES[i][0];
        new AlertDialog.Builder(this)
                .setTitle("Mesin pencari")
                .setSingleChoiceItems(n, engine, (d, i) -> {
                    engine = i;
                    prefs.edit().putInt("engine", i).apply();
                    updateHint();
                    d.dismiss();
                })
                .show();
    }

    // ---------- Menu ----------

    void showMenu(View anchor) {
        PopupMenu m = new PopupMenu(this, anchor);
        Menu mm = m.getMenu();
        mm.add(0, 1, 0, "Tab baru");
        mm.add(0, 2, 1, "Tutup tab ini");
        mm.add(0, 3, 2, "Simpan ke Home");
        mm.add(0, 4, 3, "Riwayat");
        mm.add(0, 5, 4, "Pencarian Gambar");
        mm.add(0, 6, 5, "Terjemahkan");
        mm.add(0, 7, 6, "Simpan offline");
        mm.add(0, 8, 7, "Halaman offline");
        mm.add(0, 9, 8, "Mode baca");
        mm.add(0, 10, 9, "DevTools");
        mm.add(0, 11, 10, "Mode desktop").setCheckable(true).setChecked(cur().desktop);
        mm.add(0, 12, 11, "Pintasan ke layar utama HP");
        mm.add(0, 13, 12, "Unduhan");
        mm.add(0, 14, 13, "Mesin pencari");
        mm.add(0, 15, 14, "Pengaturan");
        m.setOnMenuItemClickListener(i -> {
            switch (i.getItemId()) {
                case 1:
                    newTab(null);
                    focusUrl();
                    break;
                case 2:
                    closeCurrent();
                    break;
                case 3:
                    addBookmark();
                    break;
                case 4:
                    showHistory();
                    break;
                case 5:
                    startImageSearch();
                    break;
                case 6:
                    translate();
                    break;
                case 7:
                    saveOffline();
                    break;
                case 8:
                    showOffline();
                    break;
                case 9:
                    cur().web.evaluateJavascript(asset("reader.js"), null);
                    break;
                case 10:
                    cur().web.evaluateJavascript(
                            "(function(){if(window.eruda){eruda.show();return;}"
                                    + "var s=document.createElement('script');"
                                    + "s.src='https://cdn.jsdelivr.net/npm/eruda@3.0.1';"
                                    + "s.onload=function(){eruda.init();eruda.show();};"
                                    + "document.body.appendChild(s);})();", null);
                    break;
                case 11:
                    toggleDesktop();
                    break;
                case 12:
                    addShortcut();
                    break;
                case 13:
                    showDownloads();
                    break;
                case 14:
                    showEngines();
                    break;
                case 15:
                    showSettings();
                    break;
            }
            return true;
        });
        m.show();
    }

    void showTabs() {
        String[] n = new String[tabs.size()];
        for (int i = 0; i < n.length; i++) {
            String s = tabs.get(i).title;
            if (s == null || s.isEmpty()) s = "Tab baru";
            n[i] = (i == current ? "● " : "○ ") + s;
        }
        new AlertDialog.Builder(this)
                .setTitle("Tab (" + n.length + ")")
                .setItems(n, (d, i) -> switchTo(i))
                .setPositiveButton("Tab baru", (d, w) -> {
                    newTab(null);
                    focusUrl();
                })
                .setNeutralButton("Tutup tab ini", (d, w) -> closeCurrent())
                .setNegativeButton("Batal", null)
                .show();
    }

    void toggleDesktop() {
        Tab t = cur();
        t.desktop = !t.desktop;
        t.web.getSettings().setUserAgentString(t.desktop ? DESKTOP_UA : null);
        t.web.reload();
        toast(t.desktop ? "Mode desktop aktif" : "Mode desktop mati");
    }

    void addShortcut() {
        String url = cur().web.getUrl();
        if (!isWebUrl(url)) {
            toast("Buka sebuah situs dulu");
            return;
        }
        ShortcutManager sm = getSystemService(ShortcutManager.class);
        if (sm == null || !sm.isRequestPinShortcutSupported()) {
            toast("Launcher tidak mendukung pintasan");
            return;
        }
        String label = cur().web.getTitle();
        if (label == null || label.trim().isEmpty()) label = url;
        if (label.length() > 24) label = label.substring(0, 24);
        Intent i = new Intent(this, MainActivity.class)
                .setAction(Intent.ACTION_VIEW)
                .setData(Uri.parse(url));
        ShortcutInfo info = new ShortcutInfo.Builder(this, "u" + url.hashCode())
                .setShortLabel(label)
                .setIcon(Icon.createWithResource(this, R.mipmap.ic_launcher))
                .setIntent(i)
                .build();
        sm.requestPinShortcut(info, null);
    }

    // ---------- Terjemahkan ----------

    void translate() {
        final String u = cur().web.getUrl();
        if (!isWebUrl(u)) {
            toast("Buka sebuah situs dulu");
            return;
        }
        String[] n = new String[LANGS.length];
        for (int k = 0; k < n.length; k++) n[k] = LANGS[k][0];
        new AlertDialog.Builder(this)
                .setTitle("Terjemahkan halaman ke")
                .setItems(n, (d, i) -> cur().web.loadUrl(
                        "https://translate.google.com/translate?sl=auto&tl=" + LANGS[i][1]
                                + "&u=" + Uri.encode(u)))
                .setNegativeButton("Batal", null)
                .show();
    }

    // ---------- Simpan halaman offline ----------

    File offlineDir() {
        File d = getExternalFilesDir("offline");
        if (d == null) d = new File(getFilesDir(), "offline");
        d.mkdirs();
        return d;
    }

    void saveOffline() {
        String u = cur().web.getUrl();
        if (!isWebUrl(u)) {
            toast("Buka sebuah situs dulu");
            return;
        }
        String t = cur().web.getTitle();
        String base = t == null ? "" : t.replaceAll("[^A-Za-z0-9 _-]", "").trim();
        if (base.isEmpty()) {
            String host = Uri.parse(u).getHost();
            base = host == null ? "halaman" : host;
        }
        if (base.length() > 40) base = base.substring(0, 40);
        File f = new File(offlineDir(), base + ".mht");
        if (f.exists()) f = new File(offlineDir(), base + "-" + (System.currentTimeMillis() % 100000) + ".mht");
        toast("Menyimpan...");
        cur().web.saveWebArchive(f.getAbsolutePath(), false,
                value -> toast(value != null ? "Tersimpan offline" : "Gagal menyimpan"));
    }

    void showOffline() {
        File[] fs = offlineDir().listFiles((dir, name) -> name.endsWith(".mht"));
        if (fs == null || fs.length == 0) {
            toast("Belum ada halaman offline");
            return;
        }
        Arrays.sort(fs, (x, y) -> Long.compare(y.lastModified(), x.lastModified()));
        String[] n = new String[fs.length];
        for (int k = 0; k < n.length; k++) n[k] = fs[k].getName().replaceAll("\\.mht$", "");
        new AlertDialog.Builder(this)
                .setTitle("Halaman offline")
                .setItems(n, (d, i) -> offlineActions(fs[i]))
                .setNegativeButton("Tutup", null)
                .show();
    }

    void offlineActions(File f) {
        new AlertDialog.Builder(this)
                .setTitle(f.getName().replaceAll("\\.mht$", ""))
                .setItems(new String[]{"Buka", "Hapus"}, (d, i) -> {
                    if (i == 0) {
                        newTab(Uri.fromFile(f).toString());
                    } else {
                        toast(f.delete() ? "Dihapus" : "Gagal menghapus");
                    }
                })
                .show();
    }

    // ---------- Pencarian gambar (lingkari) ----------

    void startImageSearch() {
        final int w = container.getWidth(), h = container.getHeight();
        if (w <= 0 || h <= 0) return;
        final Bitmap bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        int[] loc = new int[2];
        container.getLocationInWindow(loc);
        Rect src = new Rect(loc[0], loc[1], loc[0] + w, loc[1] + h);
        try {
            PixelCopy.request(getWindow(), src, bmp, res -> {
                if (res == PixelCopy.SUCCESS) showLasso(bmp);
                else toast("Gagal mengambil layar");
            }, new Handler(Looper.getMainLooper()));
        } catch (Exception e) {
            toast("Gagal mengambil layar");
        }
    }

    TextView lbl(String text, View.OnClickListener c) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextColor(0xFFFFFFFF);
        v.setTextSize(15);
        v.setTypeface(null, android.graphics.Typeface.BOLD);
        v.setGravity(Gravity.CENTER);
        v.setOnClickListener(c);
        return v;
    }

    void showLasso(Bitmap bmp) {
        if (lassoBox != null) closeLasso();
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setBackgroundColor(0xFF111111);
        box.setClickable(true);

        TextView hint = new TextView(this);
        hint.setText("Lingkari bagian yang ingin dicari");
        hint.setTextColor(0xFFFFFFFF);
        hint.setTextSize(14);
        hint.setGravity(Gravity.CENTER);
        hint.setPadding(0, dp(14), 0, dp(14));

        LassoView lv = new LassoView(this, bmp);
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.addView(lbl("Batal", v -> closeLasso()), new LinearLayout.LayoutParams(0, -1, 1f));
        bar.addView(lbl("Ulangi", v -> lv.reset()), new LinearLayout.LayoutParams(0, -1, 1f));
        bar.addView(lbl("Cari", v -> {
            Bitmap c = lv.crop();
            if (c == null) {
                toast("Lingkari dulu bagian yang ingin dicari");
                return;
            }
            String b64 = encode(c);
            closeLasso();
            pickImageEngine(b64);
        }), new LinearLayout.LayoutParams(0, -1, 1f));

        box.addView(hint, new LinearLayout.LayoutParams(-1, -2));
        box.addView(lv, new LinearLayout.LayoutParams(-1, 0, 1f));
        box.addView(bar, new LinearLayout.LayoutParams(-1, dp(52)));
        rootLayout.addView(box, new FrameLayout.LayoutParams(-1, -1));
        lassoBox = box;
    }

    void closeLasso() {
        if (lassoBox == null) return;
        rootLayout.removeView(lassoBox);
        lassoBox = null;
    }

    String encode(Bitmap c) {
        float s = Math.min(1f, 900f / Math.max(c.getWidth(), c.getHeight()));
        Bitmap o = c;
        if (s < 1f) {
            o = Bitmap.createScaledBitmap(c, Math.max(1, Math.round(c.getWidth() * s)),
                    Math.max(1, Math.round(c.getHeight() * s)), true);
        }
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        o.compress(Bitmap.CompressFormat.JPEG, 85, bo);
        return Base64.encodeToString(bo.toByteArray(), Base64.NO_WRAP);
    }

    void pickImageEngine(String b64) {
        String[] n = new String[IMG.length + 1];
        for (int k = 0; k < IMG.length; k++) n[k] = IMG[k][0];
        n[IMG.length] = "Semua sumber (buka semuanya)";
        new AlertDialog.Builder(this)
                .setTitle("Cari gambar di")
                .setItems(n, (d, i) -> {
                    if (i < IMG.length) {
                        openUpload(IMG[i], b64);
                    } else {
                        for (String[] e : IMG) openUpload(e, b64);
                    }
                })
                .setNegativeButton("Batal", null)
                .show();
    }

    void openUpload(String[] e, String b64) {
        boolean file = e[3].equals("file");
        String html = "<!doctype html><html><head><meta charset=utf-8>"
                + "<meta name=viewport content='width=device-width,initial-scale=1'>"
                + "<title>Mencari...</title></head>"
                + "<body style='font-family:sans-serif;text-align:center;color:#666;padding-top:40vh'>"
                + "Mengunggah ke " + e[0] + "...<form id=f method=post enctype=multipart/form-data></form>"
                + "<script>var f=document.getElementById('f');f.action='" + e[1] + "';var b='" + b64 + "';"
                + (file
                ? "var s=atob(b),u=new Uint8Array(s.length);for(var i=0;i<s.length;i++)u[i]=s.charCodeAt(i);"
                + "var dt=new DataTransfer();dt.items.add(new File([u],'image.jpg',{type:'image/jpeg'}));"
                + "var x=document.createElement('input');x.type='file';x.name='" + e[2] + "';"
                + "f.appendChild(x);x.files=dt.files;"
                : "var x=document.createElement('input');x.type='hidden';x.name='" + e[2] + "';"
                + "x.value=b;f.appendChild(x);")
                + "f.submit();</script></body></html>";
        Tab t = createTab();
        t.web.loadDataWithBaseURL("https://nusa.invalid/", html, "text/html", "UTF-8", null);
    }

    // ---------- Unduhan ----------

    void download(String url, String ua, String cd, String mime) {
        if (Build.VERSION.SDK_INT <= 28
                && checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQ_STORAGE);
            toast("Izinkan penyimpanan, lalu unduh lagi");
            return;
        }
        try {
            String name = URLUtil.guessFileName(url, cd, mime);
            DownloadManager.Request r = new DownloadManager.Request(Uri.parse(url));
            r.setMimeType(mime);
            r.addRequestHeader("User-Agent", ua);
            String ck = CookieManager.getInstance().getCookie(url);
            if (ck != null) r.addRequestHeader("Cookie", ck);
            r.setTitle(name);
            r.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            r.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name);
            ((DownloadManager) getSystemService(DOWNLOAD_SERVICE)).enqueue(r);
            toast("Mengunduh: " + name);
        } catch (Exception e) {
            toast("Gagal mengunduh file ini");
        }
    }

    void showDownloads() {
        DownloadManager dm = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
        final List<String> names = new ArrayList<>();
        final List<Long> ids = new ArrayList<>();
        Cursor c = dm.query(new DownloadManager.Query());
        if (c != null) {
            try {
                while (c.moveToNext() && names.size() < 50) {
                    long id = c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_ID));
                    String title = c.getString(c.getColumnIndexOrThrow(DownloadManager.COLUMN_TITLE));
                    int st = c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS));
                    String mark = st == DownloadManager.STATUS_SUCCESSFUL ? "✓ "
                            : st == DownloadManager.STATUS_FAILED ? "✗ " : "… ";
                    names.add(mark + (title == null ? "file" : title));
                    ids.add(id);
                }
            } finally {
                c.close();
            }
        }
        AlertDialog.Builder b = new AlertDialog.Builder(this).setTitle("Unduhan");
        if (names.isEmpty()) b.setMessage("Belum ada unduhan.");
        else b.setItems(names.toArray(new String[0]), (d, i) -> openDownload(ids.get(i)));
        b.setNeutralButton("Buka folder", (d, w) -> {
            try {
                startActivity(new Intent(DownloadManager.ACTION_VIEW_DOWNLOADS));
            } catch (Exception e) {
                toast("Tidak bisa membuka folder");
            }
        });
        b.setPositiveButton("Tutup", null);
        b.show();
    }

    void openDownload(long id) {
        DownloadManager dm = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
        Uri u = dm.getUriForDownloadedFile(id);
        if (u == null) {
            toast("Unduhan belum selesai atau gagal");
            return;
        }
        try {
            startActivity(new Intent(Intent.ACTION_VIEW)
                    .setDataAndType(u, dm.getMimeTypeForDownloadedFile(id))
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION));
        } catch (Exception e) {
            toast("Tidak ada aplikasi untuk membuka file ini");
        }
    }

    // ---------- Util ----------

    String asset(String name) {
        try (InputStream in = getAssets().open(name);
             ByteArrayOutputStream o = new ByteArrayOutputStream()) {
            byte[] buf = new byte[4096];
            int r;
            while ((r = in.read(buf)) > 0) o.write(buf, 0, r);
            return new String(o.toByteArray(), StandardCharsets.UTF_8);
        } catch (IOException e) {
            return "";
        }
    }

    void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }
}
