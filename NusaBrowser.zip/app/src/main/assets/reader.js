(function () {
  function esc(s) {
    return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/"/g, '&quot;');
  }
  var root = document.querySelector('article') || document.querySelector('main') ||
    document.querySelector('[role=main]') || document.body;
  var els = root.querySelectorAll('h1,h2,h3,p,blockquote,li,pre,img');
  var h = '';
  for (var i = 0; i < els.length; i++) {
    var e = els[i], t = e.tagName.toLowerCase();
    if (t === 'img') {
      var src = e.currentSrc || e.src;
      if (src && e.naturalWidth > 200) h += '<img src="' + esc(src) + '">';
      continue;
    }
    var par = e.parentElement && e.parentElement.closest('li,blockquote');
    if (par && root.contains(par)) continue;
    var x = (e.innerText || '').trim();
    if (!x) continue;
    if ((t === 'p' || t === 'li') && x.length < 25) continue;
    h += '<' + t + '>' + esc(x) + '</' + t + '>';
  }
  if (h.length < 200) return;
  var title = document.title || '';
  var hasH1 = !!root.querySelector('h1');
  var css = 'body{font:18px/1.7 Georgia,serif;max-width:680px;margin:0 auto;padding:20px 18px 60px;' +
    'color:#222;background:#fafafa}h1,h2,h3{font-family:sans-serif;line-height:1.3}' +
    'img{max-width:100%;height:auto;border-radius:6px}' +
    'blockquote{border-left:3px solid #C62828;margin:0;padding-left:14px;color:#555}' +
    'a.x{font:14px sans-serif;color:#C62828;text-decoration:none}' +
    'pre{white-space:pre-wrap;background:#eee;padding:10px;border-radius:6px;font-size:14px}';
  var page = '<!doctype html><html><head><meta charset="utf-8">' +
    '<meta name="viewport" content="width=device-width,initial-scale=1"><title>' + esc(title) +
    '</title><style>' + css + '</style></head><body>' +
    '<a class="x" href="javascript:location.reload()">← Keluar mode baca</a>' +
    (hasH1 ? '' : '<h1>' + esc(title) + '</h1>') + h + '</body></html>';
  document.open();
  document.write(page);
  document.close();
})();
